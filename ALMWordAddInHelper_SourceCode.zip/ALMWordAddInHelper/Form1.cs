﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices.ComTypes;
using System.Collections;
using System.Threading;
using System.IO;

namespace ALMWordAddInHelper
{
   
    public partial class Form1 : Form
    {
        Stack stBookMark;
        string strOpenReq, strCloseReq, strOpenRichText, strCloseRichText;

        Microsoft.Office.Interop.Word.Application word = new Microsoft.Office.Interop.Word.Application();
        object miss = System.Reflection.Missing.Value;
        // object path = @"C:\Retish\MyDoc3.docx";
        object path = "";
        object readOnly = true;
        Microsoft.Office.Interop.Word.Document doc;
        string strPreviousLevel, strCurrentLevel, strNextLevel;
        int nPreviousLevel, nCurrentLevel, nNextLevel;
        int nParagraphCount;
        int nCurrentDots, nPrevDots;
        int nReq = 0;
        int nRichText = 0;
        BookMark objBookMark;
     //   OpenFileDialog openFileDialog1 = new OpenFileDialog();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            stBookMark = new Stack();
            strPreviousLevel = "";
            string strDirPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\";
                        
            nParagraphCount = doc.Paragraphs.Count;

            // ShowProgressBar();

            for (int i = 1; i <= nParagraphCount; i++)
            {
                // get the numbering on the paragraph
                strCurrentLevel = doc.Paragraphs[i].Range.ListFormat.ListString;
                nCurrentLevel = 9999;
                if (i != nParagraphCount) {
                    strNextLevel = doc.Paragraphs[i+1].Range.ListFormat.ListString;
                }
                else {
                    strNextLevel = "RichText";
                }
                
                // if the paragraph has numbering then it means it is a new requirement. So mark it open
                if (strCurrentLevel.Length > 0) {
                    nCurrentLevel = doc.Paragraphs[i].Range.ListFormat.ListLevelNumber;
                    Microsoft.Office.Interop.Word.Range range = doc.Paragraphs[i].Range.Duplicate;
                    range.SetRange(range.Start, range.Start);
                    range.Select();
                    strOpenReq = "OpenRequirement" + Convert.ToInt32(nReq);
                    doc.Bookmarks.Add(strOpenReq, range);
                    if (doc.Bookmarks.Exists(strOpenReq))
                    {
                        Object name = strOpenReq;
                        object oRange = range;
                        object saveWithDocument = true;
                        object missing = Type.Missing;
                        string pictureName = strDirPath + "ReqOpenBM.bmp";
                        doc.InlineShapes.AddPicture(pictureName, ref missing, ref saveWithDocument, ref oRange);
                    }
                  
                    if (stBookMark.Count > 0)
                    {
                        BookMark bk = (BookMark)stBookMark.Peek();
                        nPrevDots = bk.nLevel;
                    }
                    else
                    {
                        nPrevDots = -1;
                    }

                    nCurrentDots = nCurrentLevel;

                    int nDots = nPrevDots - nCurrentDots;

                    if (nDots >= 0) {

                        //Close the Requirement
                        Microsoft.Office.Interop.Word.Range range2 = doc.Paragraphs[i].Range.Duplicate;
                        int nBkLocation = 1;
                        while ((stBookMark.Count > 0) && (nDots >= 0))
                        {
                            BookMark bk = (BookMark)stBookMark.Pop();

                            //  range2.InsertBefore(System.Environment.NewLine);
                            // range2 = doc.Paragraphs[i].Range.Duplicate;
                          //  range2.InsertBefore(" ");
                            
                            range2.SetRange(range2.Start - nBkLocation, range2.Start - nBkLocation);
                            nBkLocation = nBkLocation + 1;
                            range2.Select();
                            strCloseReq = "CloseRequirement" + Convert.ToInt32(bk.nReqNumber);
                            doc.Bookmarks.Add(strCloseReq, range2);
                            if (doc.Bookmarks.Exists(strCloseReq))
                            {
                                Object name = strCloseReq;
                                object oRange = range2;
                                object saveWithDocument = true;
                                object missing = Type.Missing;
                                string pictureName = strDirPath + "ReqCloseBM.bmp";
                                doc.InlineShapes.AddPicture(pictureName, ref missing, ref saveWithDocument, ref oRange);
                            }

                            nDots--;
                        }
                    }
                    objBookMark = new BookMark();
                    objBookMark.strLevel = strCurrentLevel;
                    objBookMark.nReqNumber = nReq;
                    objBookMark.nLevel = nCurrentLevel;
                    stBookMark.Push(objBookMark);

                    nReq++;              
                    
                }                
                
                else 
                {
                    if (strPreviousLevel.Length > 0)
                    {
                        Microsoft.Office.Interop.Word.Range range = doc.Paragraphs[i].Range.Duplicate;
                        range.SetRange(range.Start, range.Start);
                        range.Select();
                        strOpenRichText = "Description" + Convert.ToInt32(nRichText);
                        doc.Bookmarks.Add(strOpenRichText, range);
                        if (doc.Bookmarks.Exists(strOpenRichText))
                        {
                            Object name = strOpenRichText;
                            object oRange = range;
                            object saveWithDocument = true;
                            object missing = Type.Missing;
                            string pictureName = strDirPath + "ReqDescrBM.bmp";
                            doc.InlineShapes.AddPicture(pictureName, ref missing, ref saveWithDocument, ref oRange);
                        }
                    }
                    // if a numbered paragraph follows a non numbered paragraph, then close the requirement
                /*    if (strNextLevel.Length > 0)
                    {
                        //Close the Rich Text
                        Microsoft.Office.Interop.Word.Range range2 = doc.Paragraphs[i].Range.Duplicate;
                       // range2.InsertAfter(System.Environment.NewLine);
                       // range2.Inser
                       // range2 = doc.Paragraphs[i].Range.Duplicate;
                        range2.SetRange(range2.End-1, range2.End-1);
                        range2.Select();
                        strCloseRichText = "CloseRichText" + Convert.ToInt32(nRichText);
                        doc.Bookmarks.Add(strCloseRichText, range2);
                        if (doc.Bookmarks.Exists(strCloseRichText))
                        {
                            Object name = strCloseRichText;
                            object oRange = range2;
                            object saveWithDocument = true;
                            object missing = Type.Missing;
                            string pictureName = @"C:\ReqContentClose.bmp";
                            doc.InlineShapes.AddPicture(pictureName, ref missing, ref saveWithDocument, ref oRange);
                        }                        

                    }*/
                    nRichText++;   
                }
                if (strNextLevel == "RichText")
                {
                    Microsoft.Office.Interop.Word.Range range3 = doc.Paragraphs[i].Range.Duplicate;
                    BookMark bk = (BookMark)stBookMark.Pop();

                    range3.InsertAfter(System.Environment.NewLine);
                    // range2 = doc.Paragraphs[i].Range.Duplicate;
                    range3.SetRange(range3.End+1, range3.End + 2);
                    range3.Select();
                    strCloseReq = "CloseRequirement" + Convert.ToInt32(bk.nReqNumber);
                    doc.Bookmarks.Add(strCloseReq, range3);
                    if (doc.Bookmarks.Exists(strCloseReq))
                    {
                        Object name = strCloseReq;
                        object oRange = range3;
                        object saveWithDocument = true;
                        object missing = Type.Missing;
                        string pictureName = strDirPath + "ReqCloseBM.bmp";
                        doc.InlineShapes.AddPicture(pictureName, ref missing, ref saveWithDocument, ref oRange);
                    }
                }
                strPreviousLevel = doc.Paragraphs[i].Range.ListFormat.ListString;
                if (i < 80)
                {
                    progressBar1.Value = i;
                }
               
            }
          //  Console.WriteLine(totaltext);
            doc.Close();
            word.Quit();
            progressBar1.Value = 100;
            MessageBox.Show("Bookmarking Complete!!");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Start the BackgroundWorker.
            backgroundWorker1.RunWorkerAsync();
        }

        private void btnFile_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtFileName.Text = openFileDialog1.FileName;
                path = openFileDialog1.FileName;
            }
            else
            {
                Environment.Exit(1);
            }

            try
            {
                doc = word.Documents.Open(path);
            }
            catch (Exception ex)
            {
                throw new Exception("File exception!", ex);
            }
           

        }
    }

    public class BookMark
    {
        public string strLevel;
        public int nLevel;
        public int nReqNumber;
    }

}
